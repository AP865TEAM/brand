AP865 Display Regular — v0.4

AP865Display-Regular.ttf: macOS 및 Windows 설치용 폰트
AP865Display-Regular.woff2: 웹사이트용 폰트

영문 대소문자·숫자·기본 문장부호를 지원합니다.
한글, 별도 볼드 및 이탤릭은 포함하지 않습니다.

InstrumentSerif-OFL.txt는 보조 글리프 원형의 저작권 및 라이선스입니다.
PROVENANCE.txt에는 제작 당시의 출처 기록이 보존되어 있습니다.
이 배포본은 2026-09-10 브랜드 담당자가 공개 웹 사용과 다운로드
배포 권한을 확인한 뒤 게시했습니다. 독점 권리를 주장하거나
첨부 라이선스 밖의 추가 권리를 부여하는 것은 아닙니다.
