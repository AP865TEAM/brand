AP865 Text V02 — Regular

설치 파일: AP865TextV02-Regular.ttf
폰트 내부 버전: 0.200

TTF 파일을 열어 설치한 후 디자인 앱의 폰트 메뉴에서
AP865 Text V02 / Regular를 선택하세요.

이 패키지는 현재 설치된 AP865 Text V02 원본 파일을 변경 없이 담았습니다.
Marcellus 기반 파생 서체이며, 원본 저작권 고지와 SIL Open Font License 1.1은
동봉된 OFL.txt를 확인하세요. 재배포 시 라이선스 문서를 함께 유지하세요.

웹사이트의 기본 폰트는 변경하지 않습니다.
